def hello():
    return "Hello from python!"
